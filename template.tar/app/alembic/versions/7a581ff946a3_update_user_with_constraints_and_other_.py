"""update user with constraints and other columns

Revision ID: 7a581ff946a3
Revises: 1a570cab1fad
Create Date: 2021-09-11 18:56:38.785286

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7a581ff946a3'
down_revision = '1a570cab1fad'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
