username_already_exists = {
    "detail": [
        {
            "loc": [
                "body",
                "username"
            ],
            "msg": "username already exists",
            "type": "value_error.jsondecode",                
        }
    ]
}

